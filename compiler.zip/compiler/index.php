<html>
	<head>
		<title>Online Compiler</title>
		<meta name="keywords" content="Online,Compiler,Online Compiler" />
		<link rel="shortcut icon" href="styles/favicon.ico" />
		<link rel="stylesheet" type="text/css" href="styles/style.css" />	
	</head>

	<body>
	<div id="whole">
		<div id="header">
			<!--<img src="../styles/header.png" width="1000px" height="200px" alt="BITS logo" />
			<br />-->
			<img src="images/logo-1.png" class="BITS_logo" width="300px" height="134px" alt="BITS logo" />
			<img src="images/logo-1.png" class="title_name" width="290px" height="134px" alt="Title" />
			<!--<p class="title_name">
			WILP Online Lab
			</p>-->
			<!--Build block of blue-->
			<img class="top_bar" src="../styles/BITS_bar.png" width="400px" height="6px" alt="bar" />
		</div>
		<div id="content">
			<?php
			session_start();
			 
			if(isset($_SESSION['username']))
			{
				$folder=$_SESSION['username'];
				header("Location: ./$folder/");
			}
			?>

			<div id="login_portal">
			<form action="checklogin.php" method="post">
			<table width="300" border="0" cellspacing="0" cellpadding="2">
			<tr><td>Username<td><td>:<td><td><input type="text" name="username"><td></tr>
			<tr><td>Password<td><td>:<td><td><input type="password" name="password"><td></tr>
			<tr><td colspan="2"><center><input type="submit" value="Login" /></center></td></tr>
			<?php if(isset($_GET['login_attempt']) and ($_GET['login_attempt']==1)) {?>
			<font color="red" class="error">Bad Login or Password. Please try again. <br/></font>
			<?php }?>
			</table>
			</form>
			</div>
		</div>
		<div id="bottom">
			<img class="bottom_bar" src="../styles/BITS_bar.png" width="400px" height="6px" alt="bar" /><br /><hr />
			<p class="descri">
			<strong>&nbsp;&nbsp;University of Lahore <br />
			&nbsp;&nbsp;</strong><br />
			&nbsp;&nbsp;&#169; The University of Lahore or UOL is a private university located in Lahore, Punjab, Pakistan. It was founded at collegiate level in 1999 under the IBADAT Educational Trust and was granted full degree awarding status in 2002.<br />
			&nbsp;&nbsp;Contact us : test@gmail.com</p>
			<img class="tagline" src="styles/tagline.png" width="300px" height="98px" alt="BITS_tagline" />
		</div>
	</div>
	</body>
</html>

