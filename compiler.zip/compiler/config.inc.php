<?php
$host="localhost";
$user="root";
$pass="";
$db_name="test";
$tbl_name="users";
?>
