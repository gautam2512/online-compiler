<?php
session_start();
if(!isset($_SESSION['username']))
{header('Location:../index.php');}
?>
<html>
	<head>
		<title>Online Compiler for Off-Campus Students</title>
			<meta name="keywords" content="BITS,OffCampus,Pilani,Compiler,WILPD" />
			<link rel="shortcut icon" href="../styles/favicon.ico" />
			<link rel="stylesheet" type="text/css" href="../styles/style.css" />		
		
			<script type="text/javascript" src="../js/jquery.js"></script>
			<script type="text/javascript" src="../js/compile.js"></script>
			<script type="text/javascript" src="../js/tab.js"></script>
			<script type="text/javascript" src="../js/jquery.form.js"></script>
			<script type="text/javascript">
				$(document).ready(function() { 
					// $('#form2').ajaxForm(function(msg) { 
					// 	//$('#output2').html(msg); 
					// }); 
				});
			</script>
	</head>

	<body>
	<div id="whole">
		<div id="header">
			<!--<img src="../styles/header.png" width="1000px" height="200px" alt="BITS logo" />
			<br />-->
			<img src="../images/logo-1.png" class="BITS_logo" width="300px" height="134px" alt="BITS logo" />
			<img src="../images/logo-1.png" class="title_name" width="290px" height="134px" alt="Title" />
			<!--<p class="title_name">
			WILP Online Lab
			</p>-->
			<!--Build block of blue-->
			<img class="top_bar" src="../styles/BITS_bar.png" width="400px" height="6px" alt="bar" />
		</div>
		<div id="content">
			<p id="logout">Click <a href="../logout.php">Here</a> to logout!!</p>
			<table class="code">
			<tr>
				<td class="code" style="background: #211d71;color: #fff;">	
					<form action="compile.php" method="post" id="form">
					Select Language of Interest:
						<select name="language" id="language">
							<option value="c">C</option>
							<option value="cpp">C++</option>
							<option value="java" selected>Java</option>
							<option value="python2.7">Python</option>
							<option value="python3.2">Python3</option>
						</select>
					<br />
					<strong>Enter Your code here:<br/></strong>
					<textarea name="code" rows=15 cols=100 onkeydown=insertTab(this,event) id="code"></textarea><br/>
					<span id="errorCode" class="error"></span><br/><br/>
					<strong>Sample Input please:<br/></strong>
					<textarea name="input" rows=7 cols=100 id="input"></textarea><br/><br/>
					<input type="submit" value="Submit" id="submit">
					<input type="reset" value="Reset"><br/>
					</form>
				</td>
				<td class="code" style="width: 100%;background: #211d71;color: #fff;">
					<strong>Output:</strong>
					<span id="output"></span><br/>
				</td>
			</tr>
			
		</div>
		<table>
		<div id="bottom">
			<img class="bottom_bar" src="../styles/BITS_bar.png" width="400px" height="6px" alt="bar" /><br /><hr />
			<p class="descri">
			<strong>&nbsp;&nbsp;University of Lahore <br />
			&nbsp;&nbsp;</strong><br />
			&nbsp;&nbsp;&#169; The University of Lahore or UOL is a private university located in Lahore, Punjab, Pakistan. It was founded at collegiate level in 1999 under the IBADAT Educational Trust and was granted full degree awarding status in 2002.<br />
			&nbsp;&nbsp;Contact us : test@gmail.com</p>
			<img class="tagline" src="../styles/tagline.png" width="300px" height="98px" alt="BITS_tagline" />
		</div>
		</table>
	</div>
	
	</body>
</html>
